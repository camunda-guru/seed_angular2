import {NgModule} from '@angular/core'
import {CommonModule} from "@angular/common"
import {HttpModule} from "@angular/http"
import {FormsModule} from '@angular/forms'
import {Routes, RouterModule} from '@angular/router';
import {ContactComponent} from './contact.component'
import { ContactComponentService} from './contact.componentService'
import {ContactPipeComponent} from "./contact.pipecomponent";
import {ContactUserRestAPIService} from "./contact.userRestAPIService"
import { DashboardComponent }   from './dashboard.component';
import { UserDetailComponent }  from './contact.userDetailComponent';


@NgModule(
    {
        imports:[CommonModule,FormsModule,HttpModule,RouterModule],
        declarations:[ContactComponent,ContactPipeComponent,DashboardComponent,UserDetailComponent],
        providers:[ContactComponentService,ContactUserRestAPIService],
        exports: [ ContactComponent,RouterModule ]
    }
)
export class ContactModule
{

}