
import {Pipe,PipeTransform} from '@angular/core'

@Pipe({name:'greeting'})
export class ContactPipeComponent implements PipeTransform
{
    transform(data:string)
    {
           return data? 'Welcome!!!  '+data :'';
    }
}