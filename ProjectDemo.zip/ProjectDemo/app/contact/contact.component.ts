import {Component,OnInit} from '@angular/core'
import {Contact} from './contact.componentModel'
import { ContactComponentService} from './contact.componentService'
import {ContactUserRestAPIService} from './contact.userRestAPIService'

@Component({

    selector:'app-contact',
    templateUrl:'./app/contact/contact.componentTemplate.html',
    styleUrls:['./app/contact/contact.component.css']
})


export class ContactComponent implements OnInit
{
    private msg:string;
    private contactsArray:Contact[];
    private contactObj:Contact;
    private userColl=[];
    constructor(private contactService: ContactComponentService,
                private userService:ContactUserRestAPIService)
    {

    }
    onSubmit()
    {
        this.contactsArray.push(this.contactObj);
    }
    newContact()
    {
       this.displayMessage('New Contact');
       this.contactObj=new Contact(0,'');

    }

    next()
    {
         let pos=this.contactsArray.indexOf(this.contactObj)+1;
         if(pos>=this.contactsArray.length)
             pos=0;
         this.contactObj=this.contactsArray[pos];
    }

    ngOnInit()
    {

           this.contactService.getContacts().then(response=>{
              this.contactsArray=response;
              this.contactObj=this.contactsArray[0];
           })

          this.userService.getUserData().subscribe(response=>{
               this.userColl.push(response);
          })
    }

    displayMessage(msg: string) {
        this.msg = msg;
        setTimeout(() => this.msg = '', 1500);
    }

}