import {Injectable} from '@angular/core'
import {Contact} from './contact.componentModel'


let contacts:Contact[]=[
    new Contact(4375643,'Anita'),
    new Contact(356546,'Vimal'),
    new Contact(536467657,'Jansi'),
    new Contact(5464678658,'Sachin')
]



@Injectable()
export class ContactComponentService
{

    getContacts()
    {
        return new Promise<Contact[]>(resolve => {
            setTimeout(() => { resolve(contacts); }, 300);
        });
    }

    getContact(id: number): Promise<Contact> {
        return this.getContacts()
            .then(arr =>arr.find(obj => obj.Id == id));
    }

}