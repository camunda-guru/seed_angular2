import {Http} from '@angular/http'
import{Injectable} from '@angular/core'
import 'rxjs'
import {Contact} from './contact.componentModel'

@Injectable()
export class ContactUserRestAPIService
{

  constructor(private http:Http)
  {

  }

  getUserData()
  {
      return this.http.get('https://jsonplaceholder.typicode.com/users')
          .flatMap((data) => data.json());
  }


}