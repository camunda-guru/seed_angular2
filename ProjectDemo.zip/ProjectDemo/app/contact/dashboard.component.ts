import { Component, OnInit } from '@angular/core';
import {Contact} from './contact.componentModel'
import { ContactComponentService} from './contact.componentService'

@Component({
  selector: 'my-dashboard',
  templateUrl: './app/contact/dashboard.component.html',
  styleUrls: [ './app/contact/dashboard.component.css' ]
})
export class DashboardComponent implements OnInit {

    private contactsArray:Contact[];
    private contactObj:Contact;

  constructor(private contactService: ContactComponentService) { }

  ngOnInit(): void {
      this.contactService.getContacts().then(response=>{
          this.contactsArray=response;
          this.contactsArray=this.contactsArray.slice(1,3);
          this.contactObj=this.contactsArray[0];
      })
  }
}

