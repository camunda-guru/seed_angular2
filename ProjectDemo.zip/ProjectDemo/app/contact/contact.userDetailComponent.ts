import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs'
import { Component, OnInit }        from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location }                 from '@angular/common';
import {Contact} from './contact.componentModel'
import { ContactComponentService} from './contact.componentService'

@Component({
    selector: 'user-detail',
    templateUrl: './app/contact/user-detail.component.html',
    styleUrls: [ './app/contact/user-detail.component.css' ]
})
export class UserDetailComponent implements OnInit {
    contact: Contact;

    constructor(
        private contactService: ContactComponentService,
        private route: ActivatedRoute,
        private location: Location
    ) {}

    ngOnInit(): void {
        this.route.params
            .switchMap((params) => {return this.contactService.getContact(params['Id'])})

           .subscribe(data => this.contact = data);


       /*
        this.route.params.subscribe(params => {
            console.log(params['Id']);
            this.contactService.getContact(params['Id']).then(function(data)
            {
                console.log("testing...");
                console.log(data);
                this.contact=data;
            });
        });
*/

    }

    goBack(): void {
        this.location.back();
    }
}

