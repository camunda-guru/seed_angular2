import {NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import {ContactModule} from './contact/contact.module'
import {AppComponent} from './app.component'
import {TitleComponent} from './app.titlecomponent'
import {HighlightDirective} from './app.highlight'
import {CustomerService} from "./app.customerService";
import { AppRoutingModule }     from './app-routing.module';
@NgModule(
    {
      imports:[BrowserModule,ContactModule,AppRoutingModule],
      declarations:[AppComponent,TitleComponent,HighlightDirective],
      providers:[CustomerService],
      bootstrap:[AppComponent]
    }
)
export class AppModule
{

}