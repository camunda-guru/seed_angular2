import{Injectable} from '@angular/core'



@Injectable()
export class CustomerService
{

    private customerName:string='Sujatha'

    get CustomerName():string
    {
        return this.customerName;
    }


}