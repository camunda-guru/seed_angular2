import {Component} from '@angular/core'

/*
@Component({
    selector:'citi-logo',
    templateUrl:'./app/views/app.componentTemplate.html',
    styleUrls:['./app/styles/appstyle.css']
})
*/
@Component({
    selector:'my-app',
    template:`<app-title  [ctitle]="title"></app-title>

                <nav>
                    <a routerLink="/dashboard" routerLinkActive="active">Dashboard</a>
                    
                </nav>
                <section>
                    <router-outlet></router-outlet>
                </section>
              <app-contact></app-contact>
      `

})
export class AppComponent
{

    private logoName:string='../assets/citibank.jpg';
    private title:string='CustomerForm'
}