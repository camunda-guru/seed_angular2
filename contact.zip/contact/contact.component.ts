import {Component,OnInit} from '@angular/core'
import {Contact} from './contact.componentModel'
import { ContactComponentService} from './contact.componentService'


@Component({

    selector:'app-contact',
    templateUrl:'./app/contact/contact.componentTemplate.html',
    styleUrls:['./app/contact/contact.componentStyle.css']
})


export class ContactComponent implements OnInit
{

    private contactsArray:Contact[];
    private contactObj:Contact;
    constructor(private contactService: ContactComponentService)
    {

    }
    next()
    {
         let pos=this.contactsArray.indexOf(this.contactObj)+1;
         if(pos>=this.contactsArray.length)
             pos=0;
         this.contactObj=this.contactsArray[pos];
    }

    ngOnInit()
    {

           this.contactService.getContacts().then(response=>{
              this.contactsArray=response;
              this.contactObj=this.contactsArray[0];
           })
    }


}