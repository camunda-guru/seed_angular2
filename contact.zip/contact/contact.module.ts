import {NgModule} from '@angular/core'
import {CommonModule} from "@angular/common"
import {FormsModule} from '@angular/forms'
import {ContactComponent} from './contact.component'
import { ContactComponentService} from './contact.componentService'
@NgModule(
    {
        imports:[CommonModule,FormsModule],
        declarations:[ContactComponent],
        providers:[ContactComponentService],
        exports: [ ContactComponent ]
    }
)
export class ContactModule
{

}