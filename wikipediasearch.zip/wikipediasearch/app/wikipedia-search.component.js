var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var WikipediaSearchComponent = (function () {
    function WikipediaSearchComponent(wikipediaService) {
        this.wikipediaService = wikipediaService;
        this.term = new forms_1.FormControl();
    }
    WikipediaSearchComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.items = this.term.valueChanges
            .debounceTime(400)
            .distinctUntilChanged()
            .switchMap(function (term) { return _this.wikipediaService.search(term); });
    };
    WikipediaSearchComponent = __decorate([
        core_1.Component({
            selector: 'wikipedia-search',
            template: "\n    <div>\n      <h2>Wikipedia Search</h2>\n      <input type=\"text\" [formControl]=\"term\">\n      <ul>\n        <li *ngFor=\"let item of items | async\">{{item}}</li>\n      </ul>\n    </div>  \n  "
        })
    ], WikipediaSearchComponent);
    return WikipediaSearchComponent;
})();
exports.WikipediaSearchComponent = WikipediaSearchComponent;
/*
Copyright 2016 thoughtram GmbH. All Rights Reserved.
Use of this source code is governed by an TTML-style license that
can be found in the license.txt file at http://thoughtram.io/license.txt
*/ 
//# sourceMappingURL=wikipedia-search.component.js.map