import {Component} from '@angular/core'

@Component({
    selector:'citi-logo',
    template:`<h1>Logo Place Holder</h1>`
})
export class AppComponent
{

}