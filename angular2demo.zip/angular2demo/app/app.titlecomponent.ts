import {Component,Input} from '@angular/core'
import {CustomerService} from "./app.customerService";

@Component({
    selector:'app-title',
    templateUrl:'./app/views/app.titlecomponentTemplate.html',
    styleUrls:['./app/styles/appstyle.css']
})


export class TitleComponent
{
    @Input() title = '';
 private subtitle:string='Registration'
 private customerName:string=''
    constructor(customerService:CustomerService)
    {
        this.customerName=customerService.CustomerName;
    }

}