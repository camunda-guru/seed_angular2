import {NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import {CommonModule} from "@angular/common"
import {AppComponent} from './app.component'
import {TitleComponent} from './app.titlecomponent'
import {HighlightDirective} from './app.highlight'
import {CustomerService} from "./app.customerService";

@NgModule(
    {
      imports:[BrowserModule,CommonModule],
      declarations:[AppComponent,TitleComponent,HighlightDirective],
      providers:[CustomerService],
      bootstrap:[AppComponent]
    }
)
export class AppModule
{

}