import {Component} from '@angular/core'

/*
@Component({
    selector:'citi-logo',
    templateUrl:'./app/views/app.componentTemplate.html',
    styleUrls:['./app/styles/appstyle.css']
})
*/
@Component({
    selector:'my-app',
    template:`<app-title  [title]="title"></app-title>`

})
export class AppComponent
{

    private logoName:string='../assets/citibank.jpg';
    private title:string='CustomerForm'
}